package com.manager.task.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagerApplcation {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagerApplcation.class, args);
	}

}
